package in.wptrafficanalyzer.viewpagerdemo;


import java.util.ArrayList;
import java.util.List;

import in.wptrafficanalyzer.viewpagerdemo.R;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class MoviesFragment extends Fragment {

	String[] member_name1;
	 TypedArray profile_pic1;
	 String[] status1;
	 
	 List<RowItem> rowItems;
	 ListView mylistview;
	 
	 public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {

			View rootView = inflater.inflate(R.layout.fragment_movies, container, false);
			
			return rootView;
		}

	 @Override
	public void onStart() {
	  super.onStart();

	  rowItems = new ArrayList<RowItem>();

	  member_name1 = getResources().getStringArray(R.array.Member_name);

	  profile_pic1 = getResources().obtainTypedArray(R.array.profile_pic);

	  status1 = getResources().getStringArray(R.array.status);


	  for (int i = 0; i <= member_name1.length; i++) {
	   RowItem item = new RowItem(member_name1[i], profile_pic1.getResourceId(1, -1), status1[i]);
	   rowItems.add(item);
	  }

	  mylistview = (ListView)getView().findViewById(R.id.list);
	  CustomAdapter adapter = new CustomAdapter(getActivity().getBaseContext(), rowItems);
	  mylistview.setAdapter(adapter);
	  profile_pic1.recycle();
	  mylistview.setOnItemClickListener(mMessageClickedHandler);

	 }
	 private OnItemClickListener mMessageClickedHandler = new OnItemClickListener(){
	 public void onItemClick(AdapterView<?> parent, View view, int position,
	   long id) {

	  String member_name = rowItems.get(position).getMember_name();
	  Toast.makeText(getActivity().getApplicationContext(), "" + member_name+" is killed",
	    Toast.LENGTH_SHORT).show();
	 }

	};
}